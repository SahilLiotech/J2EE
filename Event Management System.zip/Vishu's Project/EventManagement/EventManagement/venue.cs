﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EventManagement
{
    public partial class venue : Form
    {
        string ConString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\Vishu's Project\EventManagement\EventManagement\EventManagement.mdf;Integrated Security=True";
        public venue()
        {
            InitializeComponent();
           
        }

        private void LoadData()
        {
           SqlConnection con = new SqlConnection(ConString);
           con.Open();
           string query = "SELECT * FROM Venue";
           SqlDataAdapter sd = new SqlDataAdapter(query, con);
           DataTable dt = new DataTable();
           sd.Fill(dt);
           dataGridView1.DataSource = dt;
        }

        public void clearTextBox()
        {
            textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = "";
        }


        private void venue_Load(object sender, EventArgs e)
        {
            LoadData();
            dataGridView1.ClearSelection();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                textBox1.Text = row.Cells["Vname"].Value.ToString();
                textBox2.Text = row.Cells["VCapacity"].Value.ToString();
                textBox3.Text = row.Cells["VAddress"].Value.ToString();
                textBox4.Text = row.Cells["VManager"].Value.ToString();
                textBox5.Text = row.Cells["VPhone"].Value.ToString();
            }
        }


        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            String query = "INSERT INTO Venue(Vname,VCapacity,VAddress,VManager,VPhone)VALUES(@a,@b,@c,@d,@e)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@a", textBox1.Text);
            cmd.Parameters.AddWithValue("@b", textBox2.Text);
            cmd.Parameters.AddWithValue("@c", textBox3.Text);
            cmd.Parameters.AddWithValue("@d", textBox4.Text);
            cmd.Parameters.AddWithValue("@e", textBox5.Text);

            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Record Inserted Successfully...");
                LoadData();
            }
            else
            {
                MessageBox.Show("Something Went Wrong Insert Operation Can't Be Completed");
            }
            clearTextBox();

            con.Close();
        }



        private void button2_Click(object sender, EventArgs e)
        {
                int selectedRowIndex = dataGridView1.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = dataGridView1.Rows[selectedRowIndex];
                int venueId = Convert.ToInt32(selectedRow.Cells["VId"].Value);

                SqlConnection con = new SqlConnection(ConString);
            
                con.Open();
                string query = "UPDATE Venue SET VName = @name, VCapacity = @capacity, VAddress = @address, VManager = @manager, VPhone = @phone WHERE VId = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", venueId);
                cmd.Parameters.AddWithValue("@name", textBox1.Text);
                cmd.Parameters.AddWithValue("@capacity", textBox2.Text);
                cmd.Parameters.AddWithValue("@address", textBox3.Text);
                cmd.Parameters.AddWithValue("@manager", textBox4.Text);
                cmd.Parameters.AddWithValue("@phone", textBox5.Text);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Record Updated Successfully...");
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Something Went Wrong. Update Operation Can't Be Completed.");
                }

                clearTextBox();
                con.Close();
         }

        private void button3_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
            DataGridViewRow selectedRow = dataGridView1.Rows[selectedRowIndex];
            int venueId = Convert.ToInt32(selectedRow.Cells["VId"].Value);

            if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                SqlConnection con = new SqlConnection(ConString);

                con.Open();
                string query = "DELETE FROM Venue WHERE VId = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", venueId);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Record Deleted Successfully...");
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Something Went Wrong. Delete Operation Can't Be Completed.");
                }
                clearTextBox();
                con.Close();
            }
        }
       

        private void eventsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            EventForm form = new EventForm();
            form.Show();
            dataGridView1.ClearSelection();
        }

        private void venuesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Show();
            dataGridView1.ClearSelection();

        }

        private void dashboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard form = new Dashboard();
            form.Show();
            dataGridView1.ClearSelection();
        }

        private void customersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            customer form = new customer();
            form.Show();
            dataGridView1.ClearSelection();
        }
        private void feedbacksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            feedback form = new feedback();
            form.Show();
            dataGridView1.ClearSelection();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            clearTextBox();
            dataGridView1.ClearSelection();
        }


    }
}
