﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EventManagement
{
    public partial class EventForm : Form
    {
        string ConString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\Vishu's Project\EventManagement\EventManagement\EventManagement.mdf;Integrated Security=True";
        public EventForm()
        {
            InitializeComponent();
        }

        private void EventForm_Load(object sender, EventArgs e)
        {
            LoadData();
            dataGridView1.ClearSelection();
            LoadVenueDropdown();
            LoadCustomerDropdown();
            dataGridView1.ClearSelection();
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LoadData()
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT * FROM Event";
            SqlDataAdapter sd = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void LoadVenueDropdown()
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT VId FROM Venue";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                comboBox1.Items.Add(reader["VId"].ToString());
            }

            reader.Close();
            con.Close();
        }

        private void LoadCustomerDropdown()
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT CustId FROM Customer";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                comboBox2.Items.Add(reader["CustId"].ToString());
            }

            reader.Close();
            con.Close();
        }

        private void clearTextBoxes()
        {
            textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = "";
            comboBox1.Text = comboBox2.Text = comboBox3.Text = "";
        }

     
        private void eventsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Show();
            dataGridView1.ClearSelection();
        }

        private void venueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            venue form = new venue();
            form.Show();
            dataGridView1.ClearSelection();
        }
        private void dashboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard form = new Dashboard();
            form.Show();
            dataGridView1.ClearSelection();
        }


        private void customersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            customer form = new customer();
            form.Show();
            dataGridView1.ClearSelection();
        }

        private void feedBacksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            feedback form = new feedback();
            form.Show();
            dataGridView1.ClearSelection();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(comboBox1.Text))
            {
                string selectedVenueId = comboBox1.Text;
                SqlConnection con = new SqlConnection(ConString);
                con.Open();
                string query = "SELECT VName FROM Venue WHERE VId = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", selectedVenueId);

                object venueName = cmd.ExecuteScalar();
                if (venueName != null)
                {
                    textBox2.Text = venueName.ToString();
                }

                con.Close();
            }
        }

       

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(comboBox2.Text))
            {
                string selectedCustomerId = comboBox2.Text;
                SqlConnection con = new SqlConnection(ConString);
                con.Open();
                string query = "SELECT CustName FROM Customer WHERE CustId = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", selectedCustomerId);

                object customerName = cmd.ExecuteScalar();
                if (customerName != null)
                {
                    textBox3.Text = customerName.ToString();
                }

                con.Close();
            }
        }


        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "INSERT INTO Event(VenueId, EvName, EvDate, EvVenue, EvDuration, EvCustId, EvCustName, EvStatus) " +
                "VALUES (@venueId, @name, @date, @venue, @duration, @customerId, @customerName, @status)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@venueId", comboBox1.Text);
            cmd.Parameters.AddWithValue("@name", textBox1.Text);
            cmd.Parameters.AddWithValue("@date", dateTimePicker1.Value.ToString("d MMM yyyy"));
            cmd.Parameters.AddWithValue("@venue", textBox2.Text);
            cmd.Parameters.AddWithValue("@duration", textBox4.Text);
            cmd.Parameters.AddWithValue("@customerId", comboBox2.Text);
            cmd.Parameters.AddWithValue("@customerName", textBox3.Text);
            cmd.Parameters.AddWithValue("@status", comboBox3.Text);

            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Event Record Inserted Successfully...");
                LoadData();
            }
            else
            {
                MessageBox.Show("Something Went Wrong. Insert Operation Can't Be Completed");
            }

            clearTextBoxes();
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = dataGridView1.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = dataGridView1.Rows[selectedRowIndex];
            int eventId = Convert.ToInt32(selectedRow.Cells["EvId"].Value);

            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "UPDATE Event SET VenueId = @venueId, EvName = @name, EvDate = @date, EvVenue = @venue, " +
                "EvDuration = @duration, EvCustId = @customerId, EvCustName = @customerName, EvStatus = @status " +
                "WHERE EvId = @id";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@id", eventId);
            cmd.Parameters.AddWithValue("@venueId", comboBox1.Text);
            cmd.Parameters.AddWithValue("@name", textBox1.Text);
            cmd.Parameters.AddWithValue("@date", dateTimePicker1.Value.ToString("d MMM yyyy"));
            cmd.Parameters.AddWithValue("@venue", textBox2.Text);
            cmd.Parameters.AddWithValue("@duration", textBox4.Text);
            cmd.Parameters.AddWithValue("@customerId", comboBox2.Text);
            cmd.Parameters.AddWithValue("@customerName", textBox3.Text);
            cmd.Parameters.AddWithValue("@status", comboBox3.Text);

            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Event Record Updated Successfully...");
                LoadData();
            }
            else
            {
                MessageBox.Show("Something Went Wrong. Update Operation Can't Be Completed.");
            }

            clearTextBoxes();
            con.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
            DataGridViewRow selectedRow = dataGridView1.Rows[selectedRowIndex];
            int eventId = Convert.ToInt32(selectedRow.Cells["EvId"].Value);

            if (MessageBox.Show("Are you sure you want to delete this event record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                SqlConnection con = new SqlConnection(ConString);
                con.Open();
                string query = "DELETE FROM Event WHERE EvId = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", eventId);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Event Record Deleted Successfully...");
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Something Went Wrong. Delete Operation Can't Be Completed.");
                }

                clearTextBoxes();
                con.Close();
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            clearTextBoxes();
            dataGridView1.ClearSelection();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                comboBox1.Text = row.Cells["VenueId"].Value.ToString();
                textBox1.Text = row.Cells["EvName"].Value.ToString();
                dateTimePicker1.Value = Convert.ToDateTime(row.Cells["EvDate"].Value);
                textBox2.Text = row.Cells["EvVenue"].Value.ToString();
                textBox4.Text = row.Cells["EvDuration"].Value.ToString();
                comboBox2.Text = row.Cells["EvCustId"].Value.ToString();
                comboBox3.Text = row.Cells["EvStatus"].Value.ToString();
                textBox3.Text = row.Cells["EvCustName"].Value.ToString();
            }
        }
     

    }
}
