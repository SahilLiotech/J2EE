﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EventManagement
{
    public partial class customer : Form
    {
        string ConString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\Vishu's Project\EventManagement\EventManagement\EventManagement.mdf;Integrated Security=True";
        public customer()
        {
            InitializeComponent();
        }

        private void customer_Load(object sender, EventArgs e)
        {
            LoadData();
            dataGridView1.ClearSelection();
        }
        private void LoadData()
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT * FROM Customer";
            SqlDataAdapter sd = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        public void clearTextBoxes()
        {
            textBox1.Text = textBox2.Text = "";
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                textBox1.Text = row.Cells["CustName"].Value.ToString();
                textBox2.Text = row.Cells["CustPhone"].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "INSERT INTO Customer(CustName, CustPhone) VALUES (@name, @phone)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@name", textBox1.Text);
            cmd.Parameters.AddWithValue("@phone", textBox2.Text);

            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Record Inserted Successfully...");
                LoadData();
            }
            else
            {
                MessageBox.Show("Something Went Wrong. Insert Operation Can't Be Completed.");
            }

            clearTextBoxes();
            con.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = dataGridView1.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = dataGridView1.Rows[selectedRowIndex];
            int customerId = Convert.ToInt32(selectedRow.Cells["CustId"].Value);

            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "UPDATE Customer SET CustName = @name, CustPhone = @phone WHERE CustId = @id";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@id", customerId);
            cmd.Parameters.AddWithValue("@name", textBox1.Text);
            cmd.Parameters.AddWithValue("@phone", textBox2.Text);

            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Record Updated Successfully...");
                LoadData();
            }
            else
            {
                MessageBox.Show("Something Went Wrong. Update Operation Can't Be Completed.");
            }

            clearTextBoxes();
            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
            DataGridViewRow selectedRow = dataGridView1.Rows[selectedRowIndex];
            int customerId = Convert.ToInt32(selectedRow.Cells["CustId"].Value);

            if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                SqlConnection con = new SqlConnection(ConString);
                con.Open();
                string query = "DELETE FROM Customer WHERE CustId = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", customerId);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Record Deleted Successfully...");
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Something Went Wrong. Delete Operation Can't Be Completed.");
                }

                clearTextBoxes();
                con.Close();

            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            clearTextBoxes();
            dataGridView1.ClearSelection();            
        }

        private void eventsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            EventForm form = new EventForm();
            form.Show();
            dataGridView1.ClearSelection();
        }

        private void venuesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            venue form = new venue();
            form.Show();
            dataGridView1.ClearSelection();
        }

        private void dashboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard form = new Dashboard();
            form.Show();
            dataGridView1.ClearSelection();
        }

        private void customersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Show();
            dataGridView1.ClearSelection();
        }

        private void feedbacksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            feedback form = new feedback();
            form.Show();
            dataGridView1.ClearSelection();
        }

    }
}
