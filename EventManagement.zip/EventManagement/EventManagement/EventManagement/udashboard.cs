﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EventManagement
{
    public partial class udashboard : Form
    {
        public udashboard()
        {
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Hide();
            ucustomer form = new ucustomer();
            form.Show();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
          
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            uvenue form = new uvenue();
            form.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Hide();
            uEventForms form = new uEventForms();
            form.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            this.Hide();
            uFeedback form = new uFeedback();
            form.Show();
        }
    }
}
