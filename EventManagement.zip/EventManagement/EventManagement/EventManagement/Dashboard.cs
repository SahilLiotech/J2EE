﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EventManagement
{
    public partial class Dashboard : Form
    {
        private string ConString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\Vishu's Project\EventManagement\EventManagement\EventManagement.mdf;Integrated Security=True";
        

        public Dashboard()
        {
            InitializeComponent();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            getEventCount();
            getVenueCount();
            getCustomerCount();
            getExcellentCount();
            getGoodCount();
            getOkayCount();
            getBadCount();
        }

        public void getEventCount()
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT COUNT(*) FROM Event";
            DataTable dt=new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(query,con);
            da.Fill(dt);
            label3.Text = dt.Rows[0][0].ToString();
            con.Close();
        }

        public void getVenueCount()
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT COUNT(*) FROM Venue";
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            da.Fill(dt);
            label5.Text = dt.Rows[0][0].ToString();
            con.Close();
        }

        public void getCustomerCount()
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT COUNT(*) FROM Customer";
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            da.Fill(dt);
            label7.Text = dt.Rows[0][0].ToString();
            con.Close();
        }

        public void getExcellentCount()
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT COUNT(*) FROM Feedback WHERE OverAll="+1+" ";
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            da.Fill(dt);
            label13.Text = dt.Rows[0][0].ToString();
            con.Close();
        }

        public void getGoodCount()
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT COUNT(*) FROM Feedback WHERE OverAll=" + 2 + " ";
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            da.Fill(dt);
            label14.Text = dt.Rows[0][0].ToString();
            con.Close();
        }

        public void getOkayCount()
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT COUNT(*) FROM Feedback WHERE OverAll=" + 3 + " ";
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            da.Fill(dt);
            label15.Text = dt.Rows[0][0].ToString();
            con.Close();
        }

        public void getBadCount()
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT COUNT(*) FROM Feedback WHERE OverAll=" + 4 + " ";
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            da.Fill(dt);
            label16.Text = dt.Rows[0][0].ToString();
            con.Close();
        }

      
        private void eventsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            EventForm form = new EventForm();
            form.Show();
        }

        private void venueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            venue form = new venue();
            form.Show();
        }
        private void dashboardStripMenuItem3_Click(object sender, EventArgs e)
        {
            this.Show();
        }
        private void customerstoolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            customer form = new customer();
            form.Show();
        }

        private void feedbacksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            feedback form = new feedback();
            form.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Register reg = new Register();
            reg.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login form = new Login();
            form.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

      
    }
}
