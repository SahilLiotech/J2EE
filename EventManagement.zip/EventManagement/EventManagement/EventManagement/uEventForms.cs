﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EventManagement
{
    public partial class uEventForms : Form
    {
        string ConString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\Vishu's Project\EventManagement\EventManagement\EventManagement.mdf;Integrated Security=True";
        public uEventForms()
        {
            InitializeComponent();
        }

        private void LoadData()
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT * FROM Event";
            SqlDataAdapter sd = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            udashboard form = new udashboard();
            form.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void uEventForms_Load(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
