﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EventManagement
{
    public partial class feedback : Form
    {
        string ConString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\Vishu's Project\EventManagement\EventManagement\EventManagement.mdf;Integrated Security=True";

        public feedback()
        {
            InitializeComponent();
        }

        private void feedback_Load(object sender, EventArgs e)
        {
            LoadEventIds();
            LoadFeedbackData();
            dataGridView1.ClearSelection();
        }

        private void LoadEventIds()
        {
        }

        private void LoadFeedbackData()
        {
            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            string query = "SELECT * FROM Feedback";
            SqlDataAdapter sd = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void ClearTextBoxes()
        {
           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int selectedRowIndex = dataGridView1.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = dataGridView1.Rows[selectedRowIndex];
                int feedbackId = Convert.ToInt32(selectedRow.Cells["FId"].Value);

                if (MessageBox.Show("Are you sure you want to delete this feedback record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    SqlConnection con = new SqlConnection(ConString);
                    con.Open();
                    string query = "DELETE FROM Feedback WHERE FId = @feedbackId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@feedbackId", feedbackId);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Feedback Record Deleted Successfully...");
                        LoadFeedbackData();
                    }
                    else
                    {
                        MessageBox.Show("Something Went Wrong. Delete Operation Can't Be Completed.");
                    }

                    ClearTextBoxes();
                    con.Close();
                }
            }
            else
            {
                MessageBox.Show("Please select a feedback record to delete.");
            }

        }

        private void eventsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            EventForm form = new EventForm();
            form.Show();
            dataGridView1.ClearSelection();
        }

        private void venuesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            venue form = new venue();
            form.Show();
            dataGridView1.ClearSelection();
        }

        private void dashboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard form = new Dashboard();
            form.Show();
            dataGridView1.ClearSelection();
        }

        private void customersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            customer form = new customer();
            form.Show();
            dataGridView1.ClearSelection();
        }

        private void feedbacksToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            this.Show();
            dataGridView1.ClearSelection();
        }
       
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
       
    }
}
